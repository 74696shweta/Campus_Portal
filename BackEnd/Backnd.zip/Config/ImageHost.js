const  imageHost  =  'http://localhost:9800/static/'


module.exports  = {imageHost}